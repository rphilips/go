package ssh

import "testing"

func TestSSH(t *testing.T) {
	// rootdir := "/home/rphilips/tmp"
	// skip := []string{"a", "b/c", "b/c/d/"}
	// reffile := "/home/rphilips/Desktop/time.ref"
	// after, _ := GetMTime(reffile)
	// paths, err := ChangedAfter(rootdir, after, skip)
	// t.Errorf("error: %v\n", err)
	// t.Errorf("paths: %v\n", paths)
	// t.Errorf("after: %v\n", after)
}
