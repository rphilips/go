package util

import (
	"strings"

	qfs "brocade.be/base/fs"
	qliner "github.com/peterh/liner"
)

type Ask struct {
	Prompt  string
	Repeat  bool
	IsBoole bool
	IfDir   bool
	IfFiles bool
}

var Askit = map[string]Ask{
	"awk": {
		Prompt: "AWK command",
	},
	"backup": {
		Prompt: "Backup file",
	},
	"sed": {
		Prompt: "sed command",
	},
	"search": {
		Prompt: "Search for",
	},
	"indent": {
		Prompt: "Indention length",
	},
	"replacement": {
		Prompt: "Replacement string",
	},
	"property": {
		Prompt: "Brocade property (naked|process|qtech|script|temp|web|webdav)",
	},
	"replace": {
		Prompt: "Replace with",
	},
	"files": {
		Prompt: "File/directory",
		Repeat: true,
	},
	"inputmode": {
		Prompt: "Input mode (csv|tsv [separator=<char>] [comment=<char>] [header])",
	},
	"outputmode": {
		Prompt: "Output mode (csv|tsv [separator=<char>])",
	},
	"recurse": {
		Prompt:  "Recurse through directories ?",
		IsBoole: true,
		IfDir:   true,
	},
	"windows": {
		Prompt:  "Windows EOL convention ?",
		IsBoole: true,
	},
	"unix": {
		Prompt:  "Unix EOL convention ?",
		IsBoole: true,
	},
	"regexp": {
		Prompt:  "Regular expression ?",
		IsBoole: true,
	},
	"url": {
		Prompt:  "Show as URL ?",
		IsBoole: true,
	},
	"tolower": {
		Prompt:  "To lowercase ?",
		IsBoole: true,
	},
	"isfile": {
		Prompt:  "Is this a file ?",
		IsBoole: true,
	},
	"confirm": {
		Prompt:  "Ask for confirmation the first time ?",
		IsBoole: true,
	},
	"delete": {
		Prompt:  "Delete source ?",
		IsBoole: true,
	},
	"patterns": {
		Prompt: "File basename pattern",
		Repeat: true,
		IfDir:  true,
	},
	"utf8only": {
		Prompt:  "Restrict to UTF-8 files ?",
		IsBoole: true,
		IfDir:   true,
	},
	"ext": {
		Prompt:  "Extension to basename",
		IfFiles: true,
	},
}

func AskArgs(codes []string, cwd string) (result map[string]interface{}, aborted bool) {
	asker := qliner.NewLiner()
	asker.SetCtrlCAborts(true)
	defer asker.Close()
	foundDir := false
	foundFiles := false
	result = make(map[string]interface{})

	for _, code := range codes {
		parts := strings.SplitN(code, ":", 3)
		parts = append(parts, "", "", "")
		code = strings.TrimSpace(parts[0])
		checks := strings.TrimSpace(parts[1])
		defa := strings.TrimSpace(parts[2])
		code := strings.TrimSpace(code)
		ask := Askit[code]
		isboole := ask.IsBoole
		repeat := ask.Repeat
		prompt := ask.Prompt + ": "
		ifdir := ask.IfDir
		iffiles := ask.IfFiles
		if prompt == "" {
			continue
		}
		if isboole {
			result[code] = false
		}
		if repeat {
			result[code] = make([]string, 0)
		}
		if !repeat && !isboole {
			result[code] = ""
		}
		if ifdir && !foundDir {
			continue
		}
		if iffiles && !foundFiles {
			continue
		}
		if !IsTrue(checks, result) {
			if repeat {
				result[code] = []string{}
			} else {
				if ask.IsBoole {
					result[code] = Yes(defa)
				} else {
					result[code] = defa
				}

			}
			continue
		}

		if repeat {
			give := make([]string, 0)
			for {
				giv, err := asker.PromptWithSuggestion(prompt, defa, -1)
				if err == qliner.ErrPromptAborted {
					return nil, true
				}
				giv = strings.TrimSuffix(giv, "\n")
				if giv == "" {
					result[code] = give
					break
				}
				give = append(give, giv)
				if code == "files" {
					foundFiles = true
					if code == "files" {
						if qfs.IsDir(AbsPath(giv, cwd)) {
							foundDir = true
						}
					}
				}
			}
		} else {
			give, err := asker.PromptWithSuggestion(prompt, defa, -1)
			if err == qliner.ErrPromptAborted {
				return nil, true
			}
			if ask.IsBoole {
				result[code] = Yes(give)
			} else {
				result[code] = give
			}
		}
	}
	return result, false

}

func UnYes(b bool) string {
	if b {
		return "y"
	}
	return "n"
}

func IsTrue(checks string, result map[string]interface{}) bool {
	if checks == "" {
		return true
	}
	parts := strings.SplitN(checks, ",", -1)
	for _, part := range parts {
		part = strings.TrimSpace(part)
		not := strings.HasPrefix(part, "!")
		part = strings.TrimLeft(part, "! ")
		if part == "" {
			continue
		}
		value, ok := result[part]
		if !ok {
			return not
		}
		switch v := value.(type) {
		case string:
			if not && v != "" {
				return false
			}
			if !not && v == "" {
				return false
			}
		case bool:
			if not && v {
				return false
			}
			if !not && !v {
				return false
			}
		case []string:
			if not && len(v) != 0 {
				return false
			}
			if !not && len(v) == 0 {
				return false
			}
		}
	}
	return true

}

func Confirm(prompt string) bool {
	asker := qliner.NewLiner()
	asker.SetCtrlCAborts(true)
	defer asker.Close()
	defa := "n"
	giv, err := asker.PromptWithSuggestion(prompt, defa, -1)
	if err == qliner.ErrPromptAborted {
		return false
	}
	giv = strings.TrimSuffix(giv, "\n")
	return Yes(giv)
}

func Yes(value string) bool {
	t := strings.ToLower(value)
	if t != "" && strings.Contains("jy1t", string(t[0])) {
		return true
	}
	return false
}

func AskArg(args []string, start int, rec bool, withpat bool, withutf8 bool, regexp bool) ([]string, bool, []string, bool, bool) {
	return nil, false, nil, false, false
}
