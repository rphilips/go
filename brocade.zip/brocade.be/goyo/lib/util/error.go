package util

import (
	"fmt"
)

func Error(err error) {
	fmt.Println("ERROR:", err)
}
